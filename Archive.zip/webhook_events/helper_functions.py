import requests
import sys
from static_variables import *
import boto3
import base64
import os


# Decrypts the encrypted environment variable.
def get_environment_variable(key):
    kms = boto3.client('kms')
    val = os.environ[key]
    output = kms.decrypt(CiphertextBlob=base64.b64decode(val))['Plaintext']
    return output.decode("utf-8")


# Function is called when, a list of objects have to be fetched from
# Appends the data received from each page together.
# Headers contains link to next page, as complete data may not be on a single page but multiple.
def get_data_collection_from_github_api(url):
    data = []
    while 1:
        response = get_response_from_github_api(url)
        json_response = response.json()
        data += json_response
        if LINK in response.headers:
            url = get_next_page_url(response.headers[LINK])
        else:
            url = None

        if url is None:
            break

    return data


# Function is called when, a single json object has to be fetched from github api.
def get_single_data_from_github_api(url):
    response = get_response_from_github_api(url)
    json_response = response.json()
    return json_response


# Extracts the url of next page from links field in header, returns None if next page doesn't exist.
def get_next_page_url(links):
    links = links.split(", ")
    for link in links:
        ind = link.find('next')
        if ind != -1:
            return link[1:ind - 8]

    return None


# Returns the response for certain request.
def get_response_from_github_api(url):
    token = get_environment_variable('GITHUB_TOKEN')
    headers = {'Authorization': 'token ' + token}
    response = requests.get(url, headers=headers)
    check_for_unexpected_response(response, url)
    return response


def check_for_unexpected_response(response, url):
    json_response = response.json()
    if MESSAGE in json_response:
        message = json_response[MESSAGE]
        if message.find(BAD_CREDENTIALS_MESSAGE) != -1:
            sys.exit(BAD_CREDENTIALS_MESSAGE)
        elif message.find(RATE_LIMIT_EXCEEDED_MESSAGE) != -1:
            sys.exit(RATE_LIMIT_EXCEEDED_MESSAGE)
        elif message.find(NOT_FOUND_MESSAGE) != -1:
            sys.exit(url + " is " + NOT_FOUND_MESSAGE)


def get_pr_reviewers(review_url):
    reviews_data = get_data_collection_from_github_api(review_url)
    unique_reviewers = set()
    for review in reviews_data:
        unique_reviewers.add(review[USER][LOGIN])
    reviewers = []
    for reviewer in unique_reviewers:
        user = {USER: get_developer_info_from_dynamoDB(reviewer)}
        reviewers.append(user)
    return reviewers


def get_pr_commits(commits_url):
    commits_data = get_data_collection_from_github_api(commits_url)
    commits = []
    for commit_data in commits_data:
        commit = {SHA: commit_data[SHA], COMMITED_AT: commit_data[COMMIT][AUTHOR][DATE]}
        if commit_data[AUTHOR] is None:
            commit[USER] = get_developer_info_from_dynamoDB(commit_data[COMMIT][AUTHOR][NAME])
        else:
            commit[USER] = get_developer_info_from_dynamoDB(commit_data[AUTHOR][LOGIN])
        commits.append(commit)

    return commits


def get_pr_comments(pr_url):
    review_comments = get_review_comments(pr_url + "/" + REVIEWS)
    line_comments = get_line_comments(pr_url + "/" + COMMENTS)
    comments = review_comments + line_comments
    return comments


# Returns List of comments made on outer body but not in the lines of code.
def get_review_comments(url):
    reviews = get_data_collection_from_github_api(url)

    review_comments = []
    for review in reviews:
        if review[BODY] and review[STATE] != PENDING:
            value = {USER: get_developer_info_from_dynamoDB(review[USER][LOGIN]), BODY: review[BODY],
                     SUBMITTED_AT: review[SUBMITTED_AT]}
            review_comments.append(value)

    return review_comments


# Returns List of comments made in the lines of code.
def get_line_comments(url):
    comments = get_data_collection_from_github_api(url)
    line_comments = []
    for comment in comments:
        value = {USER: get_developer_info_from_dynamoDB(comment[USER][LOGIN]), BODY: comment[BODY],
                 SUBMITTED_AT: comment[UPDATED_AT]}
        line_comments.append(value)

    return line_comments


# TODO: Merge Commit URL is obtained from MERGE COMMIT SHA,
#  which can be null in certain cases when a pull_request is closed. Need to come up with other approach.
# Returns the list of files changed for a pull request.
def get_changed_files(merge_commit_url):
    merge_commit_data = get_single_data_from_github_api(merge_commit_url)
    files_changed = []
    for file in merge_commit_data[FILES]:
        entry = {FILENAME: file[FILENAME], STATUS: file[STATUS], ADDITIONS: file[ADDITIONS], DELETIONS: file[DELETIONS]}
        files_changed.append(entry)

    return files_changed


# Extracts the useful information form the data of requested reviewers.
def get_requested_reviewers(requested_reviewers):
    output = []
    for reviewer in requested_reviewers:
        user = {USER: get_developer_info_from_dynamoDB(reviewer[LOGIN])}
        output.append(user)
    return output


def get_merged_by(merged_by):
    if merged_by is None:
        return None
    else:
        return merged_by[LOGIN]


def get_developer_info_from_dynamoDB(user):
    dynamodb = boto3.resource('dynamodb')

    table = dynamodb.Table('developer_table')

    response = table.get_item(
        Key={
            'developer': user
        }
    )
    if 'Item' in response:
        return {"name": user, "teams": response['Item']['teams']}
    else:
        return {"name": user, "teams": []}
