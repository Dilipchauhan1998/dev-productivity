from pr_data import get_entities_from_webhook_data
import hmac
from json import loads, dumps
from helper_functions import get_environment_variable


def lambda_handler(event, context):
    payload_body = loads(event["body"])
    verify_signature(event["headers"], event["body"])
    output = get_entities_from_webhook_data(payload_body)
    print(dumps(output, indent=4))
    return {
        'statusCode': 200,
        'body': "Webhook Data Sent from Lambda"
    }


# Verifies if the POST request is valid or not by verifying signature.
# Signature of respective POST request must be same as the signature generated on the basis of secret.
# Secret is entered in the webhook. Same secret has to be stored in environment variables.
def verify_signature(payload_headers, payload_body):
    header_signature = payload_headers['X-Hub-Signature']
    if header_signature is None:
        abort(403)

    sha_name, signature = header_signature.split('=')
    if sha_name != 'sha1':
        abort(501)

    secret = get_environment_variable('GITHUB_WEBHOOK_SECRET')
    secret_bytes = bytes(secret, 'utf-8')
    mac = hmac.new(secret_bytes, payload_body.encode(), digestmod='sha1')

    if not hmac.compare_digest(str(mac.hexdigest()), str(signature)):
        abort(403)
