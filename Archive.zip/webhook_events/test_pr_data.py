import unittest
import json
from unittest.mock import patch
from pr_data import *
from test_data import *
from helper_functions import *


class TestPRData(unittest.TestCase):
    def test_get_entities_from_webhook_data(self):
        for web_data, actual_output in webhook_data:
            with patch('pr_data.get_tuple_for_closed_action') as mock_get_tuple_for_closed_action, patch(
                    'pr_data.get_tuple_for_opened_action') as mock_get_tuple_for_opened_action, patch(
                'pr_data.get_tuple_for_review_action') as mock_get_tuple_for_review_action:
                mock_get_tuple_for_opened_action.return_value = "opened"
                mock_get_tuple_for_closed_action.return_value = "closed"
                mock_get_tuple_for_review_action.return_value = "review_requested"

                extracted_output = get_entities_from_webhook_data(web_data)
                self.assertEqual(actual_output, extracted_output)


if __name__ == '__main__':
    unittest.main()
