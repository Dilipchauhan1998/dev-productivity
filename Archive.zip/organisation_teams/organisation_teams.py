import json
import boto3
from developers_info import get_developers_info

# TODO: Change the organisation as suitable.
organisation = "Test-webhook"
dynamodb = boto3.resource('dynamodb')


def lambda_handler(event, context):
    developers_info = get_developers_info(organisation)
    insert_developer_info_into_dynamoDB(developers_info)

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }


def insert_developer_info_into_dynamoDB(developers_info):
    dynamoTable = dynamodb.Table('developer_table')
    for developer in developers_info:
        dynamoTable.put_item(Item=developer)

# TODO: 1. Store the github access token(OAUTH or Personal access token) in Environment Variables in Lambda and
#  Encrypt it. Permission required for token: 'read:org'
