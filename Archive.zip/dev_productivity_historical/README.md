# dev_productivity_historical
To analyse dev-productivity of organisation or repository based on github logs of historical pull request data.
