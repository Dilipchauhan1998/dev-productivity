import json
from pr_data import get_pr_data_collection
from helper_functions import convert_repo_name_to_file_name


def dev_productivity(repo_name):
    # Array of data points for each pull request of a certain repository.
    pr_collection = get_pr_data_collection(repo_name)

    # TODO : Currently writing the output in json file. The data received in pr_collection has to be pushed into data lake
    with open(convert_repo_name_to_file_name(repo_name) + '.json', 'w', encoding='utf-8') as f:
        json.dump(pr_collection, f, ensure_ascii=False, indent=4)


dev_productivity("razorpay/ifsc")

# TODO: 1. Find another approach to obtain the files change for a PR as merge commit SHA might be null.
#       2. Attach the team details for a developer, as done in 'webhook_events'
#       3. Store/ Fetch github access token(OAUTH or Personal Access Token) in get_response_from_github_api() function.
#           Permission Required: repo
