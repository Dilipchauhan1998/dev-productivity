import unittest
import json
from unittest.mock import patch
from helper_functions import *
from test_data import *


class TestStringMethods(unittest.TestCase):

    def test_get_next_page_url(self):
        for link, actual_url in links:
            next_page_url = get_next_page_url(link)
            self.assertEqual(next_page_url, actual_url)

    # This method will be used by the mock to replace requests.get
    def mocked_requests_get(*args, **kwargs):
        class MockResponse:
            def __init__(self, json_data, status_code):
                self.json_data = json_data
                self.status_code = status_code

            def json(self):
                return self.json_data

        if args[0] == 'https://api.github.com/repos/gin-gonic/gin/pulls?state=all':
            return MockResponse(response_1, 200)
        elif args[0] == 'https://api.github.com/repos/Test-webhook/test_repository/pulls?state=all':
            return MockResponse(response_2, 200)
        elif args[0] == 'https://api.github.com/repos/Test-webhook/Test_Repository/pulls?state=all':
            return MockResponse(not_found, 404)
        elif args[0] == 'https://api.github.com/repos/gin-gonic/gin/pulls/2/comments':
            return MockResponse(bad_credentials, 401)

        return MockResponse(rate_limit_exceeded, 403)

    @patch('helper_functions.requests.get', side_effect=mocked_requests_get)
    def test_get_single_data_from_github_api(self, mock_get):
        # Assert requests.get calls
        json_data = get_single_data_from_github_api('https://api.github.com/repos/gin-gonic/gin/pulls?state=all')
        self.assertEqual(json_data, response_1)

        json_data = get_single_data_from_github_api('https://api.github.com/repos/Test-webhook/test_repository/pulls?state=all')
        self.assertEqual(json_data, response_2)

        with patch('helper_functions.sys.exit') as exit_mock:
            json_data = get_single_data_from_github_api( 'https://api.github.com/repos/Test-webhook/Test_Repository/pulls?state=all')
            self.assertEqual(json_data,not_found)
            assert exit_mock.called

            json_data = get_single_data_from_github_api('https://api.github.com/repos/gin-gonic/gin/pulls/2/comments')
            self.assertEqual(json_data, bad_credentials)
            assert exit_mock.called

            json_data = get_single_data_from_github_api('https://api.github.com/repos/gin-gonic/gin/pulls/2/commits')
            self.assertEqual(json_data, rate_limit_exceeded)
            assert exit_mock.called

    @patch('helper_functions.requests.get', side_effect=mocked_requests_get)
    def test_get_response_from_github_api(self, mock_get):
        # Assert requests.get calls
        data = get_response_from_github_api('https://api.github.com/repos/gin-gonic/gin/pulls?state=all')
        self.assertEqual(data.json(), response_1)

        data = get_response_from_github_api('https://api.github.com/repos/Test-webhook/test_repository/pulls?state=all')
        self.assertEqual(data.json(), response_2)

        with patch('helper_functions.sys.exit') as exit_mock:
            data = get_response_from_github_api('https://api.github.com/repos/Test-webhook/Test_Repository/pulls?state=all')
            self.assertEqual(data.json(), not_found)
            assert exit_mock.called

            data = get_response_from_github_api('https://api.github.com/repos/gin-gonic/gin/pulls/2/comments')
            self.assertEqual(data.json(), bad_credentials)
            assert exit_mock.called

            data = get_response_from_github_api('https://api.github.com/repos/gin-gonic/gin/pulls/2/commits')
            self.assertEqual(data.json(), rate_limit_exceeded)
            assert exit_mock.called

    def test_check_for_unexpected_response(self):
        with patch('helper_functions.sys.exit') as exit_mock:
            url = 'https://api.github.com/repos/gin-gonic/gin/pulls?state=all'
            response = TestStringMethods.mocked_requests_get(url)
            check_for_unexpected_response(response, url)
            assert not exit_mock.called

            url = 'https://api.github.com/repos/Test-webhook/Test_Repository/pulls?state=all'
            response = TestStringMethods.mocked_requests_get(url)
            check_for_unexpected_response(response, url)
            assert exit_mock.called

            url = 'https://api.github.com/repos/gin-gonic/gin/pulls/2/comments'
            response = TestStringMethods.mocked_requests_get(url)
            check_for_unexpected_response(response, url)
            assert exit_mock.called

            url = 'https://api.github.com/repos/gin-gonic/gin/pulls/2/commits'
            response = TestStringMethods.mocked_requests_get(url)
            check_for_unexpected_response(response, url)
            assert exit_mock.called
            
    @patch('helper_functions.get_data_collection_from_github_api')
    def test_get_pr_commits(self, mock_get_data_collection_from_github_api):
        for url, commits, actual_commits in commits_data:
            mock_get_data_collection_from_github_api.return_value = commits

            commits_pushed = get_pr_commits(url)
            self.assertEqual(actual_commits, commits_pushed)

    @patch('helper_functions.get_data_collection_from_github_api')
    def test_get_pr_reviewers(self, mock_get_data_collection_from_github_api):
        for url, reviewers, actual_reviewers in reviewers_data:
            mock_get_data_collection_from_github_api.return_value = reviewers

            reviewers_added = get_pr_reviewers(url)
            self.assertEqual(actual_reviewers, reviewers_added)

    def test_get_requested_reviewers(self):
        for requested_reviewers_data, actual_reviewers_requested in requested_reviewers:
            reviewers_requested = get_requested_reviewers(requested_reviewers_data)
            self.assertEqual(actual_reviewers_requested, reviewers_requested)

    def test_get_pr_comments(self):
        for url, reviews, comments, actual_pr_comments in pr_comments_data:
            with patch('helper_functions.get_review_comments') as mock_get_review_comments, patch(
                    'helper_functions.get_line_comments') as mock_get_line_comments:
                mock_get_review_comments.return_value = reviews
                mock_get_line_comments.return_value = comments

                pr_comments = get_pr_comments(url)
                self.assertEqual(actual_pr_comments, pr_comments)

    @patch('helper_functions.get_data_collection_from_github_api')
    def test_get_review_comments(self, mock_get_data_collection_from_github_api):
        for url, reviews, actual_review_comments in reviews_data:
            mock_get_data_collection_from_github_api.return_value = reviews

            review_comments = get_review_comments(url)
            self.assertEqual(actual_review_comments, review_comments)

    @patch('helper_functions.get_data_collection_from_github_api')
    def test_get_line_comments(self, mock_get_data_collection_from_github_api):
        for url, comment_data, actual_comments in line_comments:
            mock_get_data_collection_from_github_api.return_value = comment_data

            comments = get_line_comments(url)
            self.assertEqual(comments, actual_comments)

    @patch('helper_functions.get_single_data_from_github_api')
    def test_get_changed_files(self, mock_get_single_data_from_github_api):
        for url, files_changed_data, actual_files_changed in merged_commit_data:
            mock_get_single_data_from_github_api.return_value = files_changed_data

            files_changed = get_changed_files(url)
            self.assertEqual(files_changed, actual_files_changed)

    def test_get_merged_by(self):

        for merged_by, actual_author in merged_data:
            author = get_merged_by(merged_by)
            self.assertEqual(actual_author, author)

    def test_convert_repo_name_to_file_name(self):
        repo_names = [('DownloadManager/main.go', 'DownloadManager_main.go'), ('test.py', 'test.py'), ('', '')]

        for repo_name, actual_file_name in repo_names:
            file_name = convert_repo_name_to_file_name(repo_name)
            self.assertEqual(actual_file_name, file_name)


if __name__ == '__main__':
    unittest.main()
