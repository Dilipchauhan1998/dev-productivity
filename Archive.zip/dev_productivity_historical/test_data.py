links = [('<https://api.github.com/repositories/20904437/pulls?state=all&page=2>; rel="next", '
                  '<https://api.github.com/repositories/20904437/pulls?state=all&page=31>; rel="last"',
                  'https://api.github.com/repositories/20904437/pulls?state=all&page=2'),
                 ('<https://api.github.com/repositories/20904437/pulls?state=all&page=2>;rel="next", '
                  '<https://api.github.com/repositories/20904437/pulls?state=all&page=31>; rel="last"',
                  'https://api.github.com/repositories/20904437/pulls?state=all&page='),
                 ('<https://api.github.com/repositories/20904437/pulls?state=all&page=2>; rel="next"',
                  'https://api.github.com/repositories/20904437/pulls?state=all&page=2'),
                 ('<https://api.github.com/repositories/20904437/pulls?state=all&page=2>; rel=""', None),
                 ('', None)]

response_1 = {"key1": "value1"}

response_2 = {"key2": "value2"}

not_found = {"message": "Not Found",
             "documentation_url": "https://developer.github.com/v3/pulls/#list-pull-requests"}

bad_credentials = {"message": "Bad credentials",
                   "documentation_url": "https://developer.github.com/v3"}

rate_limit_exceeded = {"message": "API rate limit exceeded for 115.110.137.214. (But here's the good news: Authenticated requests get a higher rate limit. Check out the documentation for more details.)",
                       "documentation_url": "https://developer.github.com/v3/#rate-limiting"}


merged_data = [({
                   "login": "captn3m0",
                   "id": 584253,
                   "node_id": "MDQ6VXNlcjU4NDI1Mw==",
                   "avatar_url": "https://avatars3.githubusercontent.com/u/584253?v=4",
                   "gravatar_id": "",
                   "url": "https://api.github.com/users/captn3m0",
                   "html_url": "https://github.com/captn3m0",
                   "followers_url": "https://api.github.com/users/captn3m0/followers",
                   "following_url": "https://api.github.com/users/captn3m0/following{/other_user}",
                   "gists_url": "https://api.github.com/users/captn3m0/gists{/gist_id}",
                   "starred_url": "https://api.github.com/users/captn3m0/starred{/owner}{/repo}",
                   "subscriptions_url": "https://api.github.com/users/captn3m0/subscriptions",
                   "organizations_url": "https://api.github.com/users/captn3m0/orgs",
                   "repos_url": "https://api.github.com/users/captn3m0/repos",
                   "events_url": "https://api.github.com/users/captn3m0/events{/privacy}",
                   "received_events_url": "https://api.github.com/users/captn3m0/received_events",
                   "type": "User",
                   "site_admin": "false"
               }, 'captn3m0'), (None, None)]


requested_reviewers = [([
                            {
                                "login": "Dilipchauhan1998",
                                "id": 39065549,
                                "node_id": "MDQ6VXNlcjM5MDY1NTQ5",
                                "avatar_url": "https://avatars3.githubusercontent.com/u/39065549?v=4",
                                "gravatar_id": "",
                                "url": "https://api.github.com/users/Dilipchauhan1998",
                                "html_url": "https://github.com/Dilipchauhan1998",
                                "followers_url": "https://api.github.com/users/Dilipchauhan1998/followers",
                                "following_url": "https://api.github.com/users/Dilipchauhan1998/following{/other_user}",
                                "gists_url": "https://api.github.com/users/Dilipchauhan1998/gists{/gist_id}",
                                "starred_url": "https://api.github.com/users/Dilipchauhan1998/starred{/owner}{/repo}",
                                "subscriptions_url": "https://api.github.com/users/Dilipchauhan1998/subscriptions",
                                "organizations_url": "https://api.github.com/users/Dilipchauhan1998/orgs",
                                "repos_url": "https://api.github.com/users/Dilipchauhan1998/repos",
                                "events_url": "https://api.github.com/users/Dilipchauhan1998/events{/privacy}",
                                "received_events_url": "https://api.github.com/users/Dilipchauhan1998/received_events",
                                "type": "User",
                                "site_admin": "false"
                            }
                         ],
                         [{"user" : "Dilipchauhan1998"}]),
                         ([],[])]


merged_commit_data = [('https://api.github.com/repos/razorpay/ifsc/commits/34448ac10832a596cbc6e4758a81deceaa3b3c91',
                       {
                        "sha": "34448ac10832a596cbc6e4758a81deceaa3b3c91",
                        "node_id": "MDY6Q29tbWl0NTA5OTkwMzM6MzQ0NDhhYzEwODMyYTU5NmNiYzZlNDc1OGE4MWRlY2VhYTNiM2M5MQ==",
                        "commit": {
                            "author": {
                                "name": "Nemo",
                                "email": "me@captnemo.in",
                                "date": "2016-04-29T15:11:28Z"
                            },
                            "committer": {
                                "name": "Nemo",
                                "email": "me@captnemo.in",
                                "date": "2016-04-29T15:11:28Z"
                            },
                            "message": "Merge pull request #1 from razorpay/php-validator\n\nPhp validator and class",
                            "tree": {
                                "sha": "3a95dfddccf488d3475e703db38d3ac880e62ca7",
                                "url": "https://api.github.com/repos/razorpay/ifsc/git/trees/3a95dfddccf488d3475e703db38d3ac880e62ca7"
                            },
                            "url": "https://api.github.com/repos/razorpay/ifsc/git/commits/34448ac10832a596cbc6e4758a81deceaa3b3c91",
                            "comment_count": 0,
                            "verification": {
                                "verified": 'false',
                                "reason": "unsigned",
                                "signature": 'null',
                                "payload": 'null'
                            }
                        },
                        "url": "https://api.github.com/repos/razorpay/ifsc/commits/34448ac10832a596cbc6e4758a81deceaa3b3c91",
                        "html_url": "https://github.com/razorpay/ifsc/commit/34448ac10832a596cbc6e4758a81deceaa3b3c91",
                        "comments_url": "https://api.github.com/repos/razorpay/ifsc/commits/34448ac10832a596cbc6e4758a81deceaa3b3c91/comments",
                        "author": {
                            "login": "captn3m0",
                            "id": 584253,
                            "node_id": "MDQ6VXNlcjU4NDI1Mw==",
                            "avatar_url": "https://avatars3.githubusercontent.com/u/584253?v=4",
                            "gravatar_id": "",
                            "url": "https://api.github.com/users/captn3m0",
                            "html_url": "https://github.com/captn3m0",
                            "followers_url": "https://api.github.com/users/captn3m0/followers",
                            "following_url": "https://api.github.com/users/captn3m0/following{/other_user}",
                            "gists_url": "https://api.github.com/users/captn3m0/gists{/gist_id}",
                            "starred_url": "https://api.github.com/users/captn3m0/starred{/owner}{/repo}",
                            "subscriptions_url": "https://api.github.com/users/captn3m0/subscriptions",
                            "organizations_url": "https://api.github.com/users/captn3m0/orgs",
                            "repos_url": "https://api.github.com/users/captn3m0/repos",
                            "events_url": "https://api.github.com/users/captn3m0/events{/privacy}",
                            "received_events_url": "https://api.github.com/users/captn3m0/received_events",
                            "type": "User",
                            "site_admin": 'false'
                        },
                        "committer": {
                            "login": "captn3m0",
                            "id": 584253,
                            "node_id": "MDQ6VXNlcjU4NDI1Mw==",
                            "avatar_url": "https://avatars3.githubusercontent.com/u/584253?v=4",
                            "gravatar_id": "",
                            "url": "https://api.github.com/users/captn3m0",
                            "html_url": "https://github.com/captn3m0",
                            "followers_url": "https://api.github.com/users/captn3m0/followers",
                            "following_url": "https://api.github.com/users/captn3m0/following{/other_user}",
                            "gists_url": "https://api.github.com/users/captn3m0/gists{/gist_id}",
                            "starred_url": "https://api.github.com/users/captn3m0/starred{/owner}{/repo}",
                            "subscriptions_url": "https://api.github.com/users/captn3m0/subscriptions",
                            "organizations_url": "https://api.github.com/users/captn3m0/orgs",
                            "repos_url": "https://api.github.com/users/captn3m0/repos",
                            "events_url": "https://api.github.com/users/captn3m0/events{/privacy}",
                            "received_events_url": "https://api.github.com/users/captn3m0/received_events",
                            "type": "User",
                            "site_admin": 'false'
                        },
                        "parents": [
                            {
                                "sha": "904ef8f4f0a25e49ffab13c0dd071b9e984251e2",
                                "url": "https://api.github.com/repos/razorpay/ifsc/commits/904ef8f4f0a25e49ffab13c0dd071b9e984251e2",
                                "html_url": "https://github.com/razorpay/ifsc/commit/904ef8f4f0a25e49ffab13c0dd071b9e984251e2"
                            },
                            {
                                "sha": "e444c584a306668d120a2bb395d9b5edf6809927",
                                "url": "https://api.github.com/repos/razorpay/ifsc/commits/e444c584a306668d120a2bb395d9b5edf6809927",
                                "html_url": "https://github.com/razorpay/ifsc/commit/e444c584a306668d120a2bb395d9b5edf6809927"
                            }
                        ],
                        "stats": {
                            "total": 457,
                            "additions": 457,
                            "deletions": 0
                        },
                        "files": [
                            {
                                "sha": "000bdf3c970ef530109fb624eb337bae7e25b574",
                                "filename": ".gitignore",
                                "status": "modified",
                                "additions": 3,
                                "deletions": 0,
                                "changes": 3,
                                "blob_url": "https://github.com/razorpay/ifsc/blob/34448ac10832a596cbc6e4758a81deceaa3b3c91/.gitignore",
                                "raw_url": "https://github.com/razorpay/ifsc/raw/34448ac10832a596cbc6e4758a81deceaa3b3c91/.gitignore",
                                "contents_url": "https://api.github.com/repos/razorpay/ifsc/contents/.gitignore?ref=34448ac10832a596cbc6e4758a81deceaa3b3c91",
                                "patch": "@@ -2,3 +2,6 @@ sheets/\n list.html\n excel_list.txt\n data/\n+\n+/vendor/\n+composer.lock\n\\ No newline at end of file"
                            },
                            {
                                "sha": "308368b2c0954833a088f5fa97c8d71b0d6ebac2",
                                "filename": "composer.json",
                                "status": "added",
                                "additions": 17,
                                "deletions": 0,
                                "changes": 17,
                                "blob_url": "https://github.com/razorpay/ifsc/blob/34448ac10832a596cbc6e4758a81deceaa3b3c91/composer.json",
                                "raw_url": "https://github.com/razorpay/ifsc/raw/34448ac10832a596cbc6e4758a81deceaa3b3c91/composer.json",
                                "contents_url": "https://api.github.com/repos/razorpay/ifsc/contents/composer.json?ref=34448ac10832a596cbc6e4758a81deceaa3b3c91",
                                "patch": "@@ -0,0 +1,17 @@\n+{\n+    \"name\": \"razorpay/ifsc\",\n+    \"description\": \"Razorpay IFSC Codes Library\",\n+    \"type\": \"library\",\n+    \"license\": \"MIT\",\n+    \"authors\": [\n+        {\n+            \"name\": \"Abhay Rana\",\n+            \"email\": \"nemo@razorpay.com\"\n+        }\n+    ],\n+    \"autoload\": {\n+        \"psr-4\": {\n+            \"Razorpay\\\\IFSC\\\\\": \"src/php\"\n+        }\n+    }\n+}"
                            }
                        ]
                     },
                     [{"filename": ".gitignore", "status": "modified", "additions": 3, "deletions": 0},
                        {"filename": "composer.json", "status": "added", "additions": 17, "deletions": 0}
                     ])]



line_comments = [('https://api.github.com/repos/Test-webhook/test_repository/pulls/3/comments',
                  [
                      {
                          "url": "https://api.github.com/repos/Test-webhook/test_repository/pulls/comments/369960570",
                          "pull_request_review_id": 347095064,
                          "id": 369960570,
                          "node_id": "MDI0OlB1bGxSZXF1ZXN0UmV2aWV3Q29tbWVudDM2OTk2MDU3MA==",
                          "diff_hunk": "@@ -89,3 +89,6 @@ def get_merged_by(merged_by):\n         return None\n     else:\n         return merged_by[LOGIN]\n+",
                          "path": "test.py",
                          "position": 4,
                          "original_position": 4,
                          "commit_id": "a59870d248aa3dac4b1fa6d69cc8787ff15dd5ac",
                          "original_commit_id": "a59870d248aa3dac4b1fa6d69cc8787ff15dd5ac",
                          "user": {
                              "login": "dilipchauhan14",
                              "id": 59637879,
                              "node_id": "MDQ6VXNlcjU5NjM3ODc5",
                              "avatar_url": "https://avatars0.githubusercontent.com/u/59637879?v=4",
                              "gravatar_id": "",
                              "url": "https://api.github.com/users/dilipchauhan14",
                              "html_url": "https://github.com/dilipchauhan14",
                              "followers_url": "https://api.github.com/users/dilipchauhan14/followers",
                              "following_url": "https://api.github.com/users/dilipchauhan14/following{/other_user}",
                              "gists_url": "https://api.github.com/users/dilipchauhan14/gists{/gist_id}",
                              "starred_url": "https://api.github.com/users/dilipchauhan14/starred{/owner}{/repo}",
                              "subscriptions_url": "https://api.github.com/users/dilipchauhan14/subscriptions",
                              "organizations_url": "https://api.github.com/users/dilipchauhan14/orgs",
                              "repos_url": "https://api.github.com/users/dilipchauhan14/repos",
                              "events_url": "https://api.github.com/users/dilipchauhan14/events{/privacy}",
                              "received_events_url": "https://api.github.com/users/dilipchauhan14/received_events",
                              "type": "User",
                              "site_admin": 'false'
                          },
                          "body": "Following Line Follows footer.",
                          "created_at": "2020-01-23T07:18:12Z",
                          "updated_at": "2020-01-23T07:18:13Z",
                          "html_url": "https://github.com/Test-webhook/test_repository/pull/3#discussion_r369960570",
                          "pull_request_url": "https://api.github.com/repos/Test-webhook/test_repository/pulls/3",
                          "author_association": "CONTRIBUTOR",
                          "_links": {
                              "self": {
                                  "href": "https://api.github.com/repos/Test-webhook/test_repository/pulls/comments/369960570"
                              },
                              "html": {
                                  "href": "https://github.com/Test-webhook/test_repository/pull/3#discussion_r369960570"
                              },
                              "pull_request": {
                                  "href": "https://api.github.com/repos/Test-webhook/test_repository/pulls/3"
                              }
                          }
                      },
                      {
                          "url": "https://api.github.com/repos/Test-webhook/test_repository/pulls/comments/369960614",
                          "pull_request_review_id": 347095127,
                          "id": 369960614,
                          "node_id": "MDI0OlB1bGxSZXF1ZXN0UmV2aWV3Q29tbWVudDM2OTk2MDYxNA==",
                          "diff_hunk": "@@ -89,3 +89,6 @@ def get_merged_by(merged_by):\n         return None",
                          "path": "test.py",
                          "position": 1,
                          "original_position": 1,
                          "commit_id": "a59870d248aa3dac4b1fa6d69cc8787ff15dd5ac",
                          "original_commit_id": "a59870d248aa3dac4b1fa6d69cc8787ff15dd5ac",
                          "user": {
                              "login": "dilipchauhan14",
                              "id": 59637879,
                              "node_id": "MDQ6VXNlcjU5NjM3ODc5",
                              "avatar_url": "https://avatars0.githubusercontent.com/u/59637879?v=4",
                              "gravatar_id": "",
                              "url": "https://api.github.com/users/dilipchauhan14",
                              "html_url": "https://github.com/dilipchauhan14",
                              "followers_url": "https://api.github.com/users/dilipchauhan14/followers",
                              "following_url": "https://api.github.com/users/dilipchauhan14/following{/other_user}",
                              "gists_url": "https://api.github.com/users/dilipchauhan14/gists{/gist_id}",
                              "starred_url": "https://api.github.com/users/dilipchauhan14/starred{/owner}{/repo}",
                              "subscriptions_url": "https://api.github.com/users/dilipchauhan14/subscriptions",
                              "organizations_url": "https://api.github.com/users/dilipchauhan14/orgs",
                              "repos_url": "https://api.github.com/users/dilipchauhan14/repos",
                              "events_url": "https://api.github.com/users/dilipchauhan14/events{/privacy}",
                              "received_events_url": "https://api.github.com/users/dilipchauhan14/received_events",
                              "type": "User",
                              "site_admin": 'false'
                          },
                          "body": "Usual above it.",
                          "created_at": "2020-01-23T07:18:22Z",
                          "updated_at": "2020-01-23T07:19:06Z",
                          "html_url": "https://github.com/Test-webhook/test_repository/pull/3#discussion_r369960614",
                          "pull_request_url": "https://api.github.com/repos/Test-webhook/test_repository/pulls/3",
                          "author_association": "CONTRIBUTOR",
                          "_links": {
                              "self": {
                                  "href": "https://api.github.com/repos/Test-webhook/test_repository/pulls/comments/369960614"
                              },
                              "html": {
                                  "href": "https://github.com/Test-webhook/test_repository/pull/3#discussion_r369960614"
                              },
                              "pull_request": {
                                  "href": "https://api.github.com/repos/Test-webhook/test_repository/pulls/3"
                              }
                          }
                      }
                  ],
                  [{"author": "dilipchauhan14", "body": "Following Line Follows footer.",
                    "submitted_at": "2020-01-23T07:18:13Z"},
                   {"author": "dilipchauhan14", "body": "Usual above it.", "submitted_at": "2020-01-23T07:19:06Z"}
                   ]),
                 ('https://api.github.com/repos/Test-webhook/test_repository/pulls/4/comments',[], [])]



reviews_data = [('https://api.github.com/repos/Test-webhook/test_repository/pulls/3/reviews',
            [
                {
                    "id": 347095064,
                    "node_id": "MDE3OlB1bGxSZXF1ZXN0UmV2aWV3MzQ3MDk1MDY0",
                    "user": {
                        "login": "dilipchauhan14",
                        "id": 59637879,
                        "node_id": "MDQ6VXNlcjU5NjM3ODc5",
                        "avatar_url": "https://avatars0.githubusercontent.com/u/59637879?v=4",
                        "gravatar_id": "",
                        "url": "https://api.github.com/users/dilipchauhan14",
                        "html_url": "https://github.com/dilipchauhan14",
                        "followers_url": "https://api.github.com/users/dilipchauhan14/followers",
                        "following_url": "https://api.github.com/users/dilipchauhan14/following{/other_user}",
                        "gists_url": "https://api.github.com/users/dilipchauhan14/gists{/gist_id}",
                        "starred_url": "https://api.github.com/users/dilipchauhan14/starred{/owner}{/repo}",
                        "subscriptions_url": "https://api.github.com/users/dilipchauhan14/subscriptions",
                        "organizations_url": "https://api.github.com/users/dilipchauhan14/orgs",
                        "repos_url": "https://api.github.com/users/dilipchauhan14/repos",
                        "events_url": "https://api.github.com/users/dilipchauhan14/events{/privacy}",
                        "received_events_url": "https://api.github.com/users/dilipchauhan14/received_events",
                        "type": "User",
                        "site_admin": "false"
                    },
                    "body": "",
                    "state": "COMMENTED",
                    "html_url": "https://github.com/Test-webhook/test_repository/pull/3#pullrequestreview-347095064",
                    "pull_request_url": "https://api.github.com/repos/Test-webhook/test_repository/pulls/3",
                    "author_association": "CONTRIBUTOR",
                    "_links": {
                        "html": {
                            "href": "https://github.com/Test-webhook/test_repository/pull/3#pullrequestreview-347095064"
                        },
                        "pull_request": {
                            "href": "https://api.github.com/repos/Test-webhook/test_repository/pulls/3"
                        }
                    },
                    "submitted_at": "2020-01-23T07:18:12Z",
                    "commit_id": "a59870d248aa3dac4b1fa6d69cc8787ff15dd5ac"
                },
                {
                    "id": 347095127,
                    "node_id": "MDE3OlB1bGxSZXF1ZXN0UmV2aWV3MzQ3MDk1MTI3",
                    "user": {
                        "login": "dilipchauhan14",
                        "id": 59637879,
                        "node_id": "MDQ6VXNlcjU5NjM3ODc5",
                        "avatar_url": "https://avatars0.githubusercontent.com/u/59637879?v=4",
                        "gravatar_id": "",
                        "url": "https://api.github.com/users/dilipchauhan14",
                        "html_url": "https://github.com/dilipchauhan14",
                        "followers_url": "https://api.github.com/users/dilipchauhan14/followers",
                        "following_url": "https://api.github.com/users/dilipchauhan14/following{/other_user}",
                        "gists_url": "https://api.github.com/users/dilipchauhan14/gists{/gist_id}",
                        "starred_url": "https://api.github.com/users/dilipchauhan14/starred{/owner}{/repo}",
                        "subscriptions_url": "https://api.github.com/users/dilipchauhan14/subscriptions",
                        "organizations_url": "https://api.github.com/users/dilipchauhan14/orgs",
                        "repos_url": "https://api.github.com/users/dilipchauhan14/repos",
                        "events_url": "https://api.github.com/users/dilipchauhan14/events{/privacy}",
                        "received_events_url": "https://api.github.com/users/dilipchauhan14/received_events",
                        "type": "User",
                        "site_admin": "false"
                    },
                    "body": "Marked Usuals.",
                    "state": "COMMENTED",
                    "html_url": "https://github.com/Test-webhook/test_repository/pull/3#pullrequestreview-347095127",
                    "pull_request_url": "https://api.github.com/repos/Test-webhook/test_repository/pulls/3",
                    "author_association": "CONTRIBUTOR",
                    "_links": {
                        "html": {
                            "href": "https://github.com/Test-webhook/test_repository/pull/3#pullrequestreview-347095127"
                        },
                        "pull_request": {
                            "href": "https://api.github.com/repos/Test-webhook/test_repository/pulls/3"
                        }
                    },
                    "submitted_at": "2020-01-23T07:19:06Z",
                    "commit_id": "a59870d248aa3dac4b1fa6d69cc8787ff15dd5ac"
                }
            ],
            [
             {"author": "dilipchauhan14", "body": "Marked Usuals.", "submitted_at": "2020-01-23T07:19:06Z"}
            ]),('https://api.github.com/repos/Test-webhook/test_repository/pulls/4/reviews', [], [])]



reviewers_data = [('https://api.github.com/repos/Test-webhook/test_repository/pulls/3/reviews',
            [
                {
                    "id": 347095064,
                    "node_id": "MDE3OlB1bGxSZXF1ZXN0UmV2aWV3MzQ3MDk1MDY0",
                    "user": {
                        "login": "dilipchauhan14",
                        "id": 59637879,
                        "node_id": "MDQ6VXNlcjU5NjM3ODc5",
                        "avatar_url": "https://avatars0.githubusercontent.com/u/59637879?v=4",
                        "gravatar_id": "",
                        "url": "https://api.github.com/users/dilipchauhan14",
                        "html_url": "https://github.com/dilipchauhan14",
                        "followers_url": "https://api.github.com/users/dilipchauhan14/followers",
                        "following_url": "https://api.github.com/users/dilipchauhan14/following{/other_user}",
                        "gists_url": "https://api.github.com/users/dilipchauhan14/gists{/gist_id}",
                        "starred_url": "https://api.github.com/users/dilipchauhan14/starred{/owner}{/repo}",
                        "subscriptions_url": "https://api.github.com/users/dilipchauhan14/subscriptions",
                        "organizations_url": "https://api.github.com/users/dilipchauhan14/orgs",
                        "repos_url": "https://api.github.com/users/dilipchauhan14/repos",
                        "events_url": "https://api.github.com/users/dilipchauhan14/events{/privacy}",
                        "received_events_url": "https://api.github.com/users/dilipchauhan14/received_events",
                        "type": "User",
                        "site_admin": "false"
                    },
                    "body": "",
                    "state": "COMMENTED",
                    "html_url": "https://github.com/Test-webhook/test_repository/pull/3#pullrequestreview-347095064",
                    "pull_request_url": "https://api.github.com/repos/Test-webhook/test_repository/pulls/3",
                    "author_association": "CONTRIBUTOR",
                    "_links": {
                        "html": {
                            "href": "https://github.com/Test-webhook/test_repository/pull/3#pullrequestreview-347095064"
                        },
                        "pull_request": {
                            "href": "https://api.github.com/repos/Test-webhook/test_repository/pulls/3"
                        }
                    },
                    "submitted_at": "2020-01-23T07:18:12Z",
                    "commit_id": "a59870d248aa3dac4b1fa6d69cc8787ff15dd5ac"
                },
                {
                    "id": 347095127,
                    "node_id": "MDE3OlB1bGxSZXF1ZXN0UmV2aWV3MzQ3MDk1MTI3",
                    "user": {
                        "login": "dilipchauhan14",
                        "id": 59637879,
                        "node_id": "MDQ6VXNlcjU5NjM3ODc5",
                        "avatar_url": "https://avatars0.githubusercontent.com/u/59637879?v=4",
                        "gravatar_id": "",
                        "url": "https://api.github.com/users/dilipchauhan14",
                        "html_url": "https://github.com/dilipchauhan14",
                        "followers_url": "https://api.github.com/users/dilipchauhan14/followers",
                        "following_url": "https://api.github.com/users/dilipchauhan14/following{/other_user}",
                        "gists_url": "https://api.github.com/users/dilipchauhan14/gists{/gist_id}",
                        "starred_url": "https://api.github.com/users/dilipchauhan14/starred{/owner}{/repo}",
                        "subscriptions_url": "https://api.github.com/users/dilipchauhan14/subscriptions",
                        "organizations_url": "https://api.github.com/users/dilipchauhan14/orgs",
                        "repos_url": "https://api.github.com/users/dilipchauhan14/repos",
                        "events_url": "https://api.github.com/users/dilipchauhan14/events{/privacy}",
                        "received_events_url": "https://api.github.com/users/dilipchauhan14/received_events",
                        "type": "User",
                        "site_admin": "false"
                    },
                    "body": "Marked Usuals.",
                    "state": "COMMENTED",
                    "html_url": "https://github.com/Test-webhook/test_repository/pull/3#pullrequestreview-347095127",
                    "pull_request_url": "https://api.github.com/repos/Test-webhook/test_repository/pulls/3",
                    "author_association": "CONTRIBUTOR",
                    "_links": {
                        "html": {
                            "href": "https://github.com/Test-webhook/test_repository/pull/3#pullrequestreview-347095127"
                        },
                        "pull_request": {
                            "href": "https://api.github.com/repos/Test-webhook/test_repository/pulls/3"
                        }
                    },
                    "submitted_at": "2020-01-23T07:19:06Z",
                    "commit_id": "a59870d248aa3dac4b1fa6d69cc8787ff15dd5ac"
                }
            ],
            [
             {"user": "dilipchauhan14"}
            ]),('https://api.github.com/repos/Test-webhook/test_repository/pulls/4/reviews', [], [])]

commits_data=[('https://api.github.com/repos/Test-webhook/test_repository/pulls/3/commits',
                  [
                    {
                        "sha": "a59870d248aa3dac4b1fa6d69cc8787ff15dd5ac",
                        "node_id": "MDY6Q29tbWl0MjM1NzQwODQ4OmE1OTg3MGQyNDhhYTNkYWM0YjFmYTZkNjljYzg3ODdmZjE1ZGQ1YWM=",
                        "commit": {
                            "author": {
                                "name": "dilipchauhan14",
                                "email": "59637879+dilipchauhan14@users.noreply.github.com",
                                "date": "2020-01-23T07:16:44Z"
                            },
                            "committer": {
                                "name": "GitHub",
                                "email": "noreply@github.com",
                                "date": "2020-01-23T07:16:44Z"
                            },
                            "message": "Update test.py\n\nAdded footer.",
                            "tree": {
                                "sha": "b417b368dd7e2dfd9bba6bdbb1a5959989322650",
                                "url": "https://api.github.com/repos/Test-webhook/test_repository/git/trees/b417b368dd7e2dfd9bba6bdbb1a5959989322650"
                            },
                            "url": "https://api.github.com/repos/Test-webhook/test_repository/git/commits/a59870d248aa3dac4b1fa6d69cc8787ff15dd5ac",
                            "comment_count": 0,
                            "verification": {
                                "verified": "true",
                                "reason": "valid",
                                "signature": "-----BEGIN PGP SIGNATURE-----\n\nwsBcBAABCAAQBQJeKUhcCRBK7hj4Ov3rIwAAdHIIAJHtix02rsYqW2j6EdqVFgzs\nQwquCnlTaNz1lxRlkjGq3EM7B+O6lOQppb3CbuV3976nc+RVA9aPCFrzJ+D6lCAD\nHTM70ez8821tCf0d7rGQF2zt/AEydh0GNqJeLK5nRhnsJ0ixd0M7oCLnB7veWIof\n20ChZP+qliHZNcFsH79jIqVwe4+OMQa9+wCJ5PaPme+zP9uxoLflqzsmVeh43+uv\nu6+FXjuOjG/mMBxUtbXRiFDNFlR0qm4HchzZX3kZI8/4x+/EYhbAGw4gTyNo+J05\nuLuKt11XvZUGFBcv8wdm6hWOA1Pfb+mj0LRE0fsjl6Ui4490TRvhfazE1h79CeQ=\n=yUfh\n-----END PGP SIGNATURE-----\n",
                                "payload": "tree b417b368dd7e2dfd9bba6bdbb1a5959989322650\nparent 2ff90bf4e5bb03061e1a75319e5340e8fd0af1ff\nauthor dilipchauhan14 <59637879+dilipchauhan14@users.noreply.github.com> 1579763804 +0530\ncommitter GitHub <noreply@github.com> 1579763804 +0530\n\nUpdate test.py\n\nAdded footer."
                            }
                        },
                        "url": "https://api.github.com/repos/Test-webhook/test_repository/commits/a59870d248aa3dac4b1fa6d69cc8787ff15dd5ac",
                        "html_url": "https://github.com/Test-webhook/test_repository/commit/a59870d248aa3dac4b1fa6d69cc8787ff15dd5ac",
                        "comments_url": "https://api.github.com/repos/Test-webhook/test_repository/commits/a59870d248aa3dac4b1fa6d69cc8787ff15dd5ac/comments",
                        "author": {
                            "login": "dilipchauhan14",
                            "id": 59637879,
                            "node_id": "MDQ6VXNlcjU5NjM3ODc5",
                            "avatar_url": "https://avatars0.githubusercontent.com/u/59637879?v=4",
                            "gravatar_id": "",
                            "url": "https://api.github.com/users/dilipchauhan14",
                            "html_url": "https://github.com/dilipchauhan14",
                            "followers_url": "https://api.github.com/users/dilipchauhan14/followers",
                            "following_url": "https://api.github.com/users/dilipchauhan14/following{/other_user}",
                            "gists_url": "https://api.github.com/users/dilipchauhan14/gists{/gist_id}",
                            "starred_url": "https://api.github.com/users/dilipchauhan14/starred{/owner}{/repo}",
                            "subscriptions_url": "https://api.github.com/users/dilipchauhan14/subscriptions",
                            "organizations_url": "https://api.github.com/users/dilipchauhan14/orgs",
                            "repos_url": "https://api.github.com/users/dilipchauhan14/repos",
                            "events_url": "https://api.github.com/users/dilipchauhan14/events{/privacy}",
                            "received_events_url": "https://api.github.com/users/dilipchauhan14/received_events",
                            "type": "User",
                            "site_admin": "false"
                        },
                        "committer": {
                            "login": "web-flow",
                            "id": 19864447,
                            "node_id": "MDQ6VXNlcjE5ODY0NDQ3",
                            "avatar_url": "https://avatars3.githubusercontent.com/u/19864447?v=4",
                            "gravatar_id": "",
                            "url": "https://api.github.com/users/web-flow",
                            "html_url": "https://github.com/web-flow",
                            "followers_url": "https://api.github.com/users/web-flow/followers",
                            "following_url": "https://api.github.com/users/web-flow/following{/other_user}",
                            "gists_url": "https://api.github.com/users/web-flow/gists{/gist_id}",
                            "starred_url": "https://api.github.com/users/web-flow/starred{/owner}{/repo}",
                            "subscriptions_url": "https://api.github.com/users/web-flow/subscriptions",
                            "organizations_url": "https://api.github.com/users/web-flow/orgs",
                            "repos_url": "https://api.github.com/users/web-flow/repos",
                            "events_url": "https://api.github.com/users/web-flow/events{/privacy}",
                            "received_events_url": "https://api.github.com/users/web-flow/received_events",
                            "type": "User",
                            "site_admin": "false"
                        },
                        "parents": [
                            {
                                "sha": "2ff90bf4e5bb03061e1a75319e5340e8fd0af1ff",
                                "url": "https://api.github.com/repos/Test-webhook/test_repository/commits/2ff90bf4e5bb03061e1a75319e5340e8fd0af1ff",
                                "html_url": "https://github.com/Test-webhook/test_repository/commit/2ff90bf4e5bb03061e1a75319e5340e8fd0af1ff"
                            }
                        ]
                    }
                ],
               [{"sha":"a59870d248aa3dac4b1fa6d69cc8787ff15dd5ac", "commited_at":"2020-01-23T07:16:44Z", "author": "dilipchauhan14"}])
             ]


pr_comments_data = [('https://api.github.com/repos/Test-webhook/test_repository/pulls/3',
                     [{"author": "dilipchauhan14", "body": "Marked Usuals.", "submitted_at": "2020-01-23T07:19:06Z"}
                     ],
                    [{"author": "dilipchauhan14", "body": "Following Line Follows footer.", "submitted_at": "2020-01-23T07:18:13Z"},
                     {"author": "dilipchauhan14", "body": "Usual above it.", "submitted_at": "2020-01-23T07:19:06Z"}
                    ],
                   [{"author": "dilipchauhan14", "body": "Marked Usuals.", "submitted_at": "2020-01-23T07:19:06Z"},
                    {"author": "dilipchauhan14", "body": "Following Line Follows footer.", "submitted_at": "2020-01-23T07:18:13Z"},
                    {"author": "dilipchauhan14", "body": "Usual above it.", "submitted_at": "2020-01-23T07:19:06Z"}
                   ]),
                   ('https://api.github.com/repos/Test-webhook/test_repository/pulls/4',[],[],[])]


