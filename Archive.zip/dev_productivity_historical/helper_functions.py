import requests
import sys
import time
from static_variables import *


# Returns all pull requests data received from github api.
def get_historical_data(repo_name):
    url = BASE_URL + "/" + repo_name + "/" + PULLS_ALL
    historical_data = get_data_collection_from_github_api(url)
    return historical_data


# Function is called when, a list of objects have to be fetched from
# Appends the data received from each page together.
# Headers contains link to next page, as complete data may not be on a single page but multiple.
def get_data_collection_from_github_api(url):
    data = []
    while 1:
        response = get_response_from_github_api(url)
        json_response = response.json()
        data += json_response  # Appends the data received from each page.
        if LINK in response.headers:
            url = get_next_page_url(
                response.headers[LINK])
        else:
            url = None

        if url is None:
            break

    return data


# Function is called when, a single json object has to be fetched from github api.
def get_single_data_from_github_api(url):
    response = get_response_from_github_api(url)
    json_response = response.json()
    return json_response


# Extracts the url of next page from links field in header, returns None if next page doesn't exist.
def get_next_page_url(links):
    links = links.split(", ")
    for link in links:
        ind = link.find('next')
        if ind != -1:
            return link[1:ind - 8]

    return None


# TODO: In token variable insert the access token with suitable permissions. Preferably: Fetch it securely.
# Returns the response for certain request.
def get_response_from_github_api(url):
    token = 'e898e2e3e93afc4e5da325e80c9c20f38de6f7dd'
    headers = {'Authorization': 'token ' + token}

    response = requests.get(url, headers=headers)
    check_for_unexpected_response(response, url)

    return response


def check_for_unexpected_response(response, url):
    json_response = response.json()
    if MESSAGE in json_response:
        message = json_response[MESSAGE]
        if message.find(BAD_CREDENTIALS_MESSAGE) != -1:
            sys.exit(BAD_CREDENTIALS_MESSAGE)
        elif message.find(RATE_LIMIT_EXCEEDED_MESSAGE) != -1:
            sys.exit(RATE_LIMIT_EXCEEDED_MESSAGE)
        elif message.find(NOT_FOUND_MESSAGE) != -1:
            sys.exit(url + " is " + NOT_FOUND_MESSAGE)


def get_pr_commits(commits_url):
    commits_data = get_data_collection_from_github_api(commits_url)
    commits = []
    for commit_data in commits_data:
        commit = {SHA: commit_data[SHA], COMMITED_AT: commit_data[COMMIT][AUTHOR][DATE]}
        if commit_data[AUTHOR] is None:
            commit[USER] = commit_data[COMMIT][AUTHOR][NAME]
        else:
            commit[USER] = commit_data[AUTHOR][LOGIN]
        commits.append(commit)

    return commits


def get_pr_reviewers(review_url):
    reviews_data = get_data_collection_from_github_api(review_url)
    unique_reviewers = set()
    for review in reviews_data:
        unique_reviewers.add(review[USER][LOGIN])
    reviewers = []
    for reviewer in unique_reviewers:
        user = {USER: reviewer}
        reviewers.append(user)
    return reviewers


# Extracts the useful information form the data of requested reviewers.
def get_requested_reviewers(requested_reviewers):
    output = []
    for reviewer in requested_reviewers:
        user = {USER: reviewer[LOGIN]}
        output.append(user)
    return output


def get_pr_comments(pr_url):
    review_comments = get_review_comments(pr_url + "/" + REVIEWS)
    line_comments = get_line_comments(pr_url + "/" + COMMENTS)
    comments = review_comments + line_comments
    return comments


# Returns List of comments made on outer body but not in the lines of code.
def get_review_comments(review_url):
    reviews = get_data_collection_from_github_api(review_url)

    review_comments = []
    for review in reviews:
        if review[BODY] and review[STATE] != PENDING:
            value = {AUTHOR: review[USER][LOGIN], BODY: review[BODY], SUBMITTED_AT: review[SUBMITTED_AT]}
            review_comments.append(value)

    return review_comments


# Returns List of comments made in the lines of code.
def get_line_comments(comments_url):
    comments = get_data_collection_from_github_api(comments_url)
    line_comments = []
    for comment in comments:
        value = {AUTHOR: comment[USER][LOGIN], BODY: comment[BODY], SUBMITTED_AT: comment[UPDATED_AT]}
        line_comments.append(value)

    return line_comments


# TODO: Merge Commit URL is obtained from MERGE COMMIT SHA,
#  which can be null in certain cases when a pull_request is closed. Need to come up with other approach.
# Returns the list of files changed for a pull request.
def get_changed_files(merge_commit_url):
    merge_commit_data = get_single_data_from_github_api(merge_commit_url)
    files_changed = []
    for file in merge_commit_data[FILES]:
        entry = {FILENAME: file[FILENAME], STATUS: file[STATUS], ADDITIONS: file[ADDITIONS], DELETIONS: file[DELETIONS]}
        files_changed.append(entry)

    return files_changed


def get_merged_by(merged_by):
    if merged_by is None:
        return None
    else:
        return merged_by[LOGIN]


# Function won't be needed when data is pushed into data lake and not saved in json file.
def convert_repo_name_to_file_name(repo_name):
    file_name = ""
    for letter in repo_name:
        if letter == '/':
            file_name += '_'
        else:
            file_name += letter

    return file_name
